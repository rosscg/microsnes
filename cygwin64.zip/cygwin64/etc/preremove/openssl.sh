if [ -f /etc/pki/tls/ct_log_list.cnf ] && cmp -s /etc/defaults/etc/pki/tls/ct_log_list.cnf /etc/pki/tls/ct_log_list.cnf
then
    rm /etc/pki/tls/ct_log_list.cnf
fi

if [ -f /etc/pki/tls/openssl.cnf ] && cmp -s /etc/defaults/etc/pki/tls/openssl.cnf /etc/pki/tls/openssl.cnf
then
    rm /etc/pki/tls/openssl.cnf
fi

