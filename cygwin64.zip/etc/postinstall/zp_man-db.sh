[ ! -s /var/cache/man/index.db ] || /usr/bin/mandb -pq
